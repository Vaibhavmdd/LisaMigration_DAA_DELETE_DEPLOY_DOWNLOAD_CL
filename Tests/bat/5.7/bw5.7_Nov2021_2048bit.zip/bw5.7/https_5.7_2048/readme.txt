New Changes:

keystore password: tibco123
Key Alias: amx,   password:   tibco123
Key Alias: bw, 	 password :   tibco123


Files listed below: 

amx340_id.jks
Exported to amx340.pem (will be imported to BW trustKeystore)
amx340_trust.jks (need to import bw.pem)

Intergrate to one file: 
RSA1024.keystore import bw57.pem 

Those are used for BWService SSL:
bw57_id.jks
Exported to bw.pem (will be imported to amx trustkeystore)
bw57_trust.jks 

Intergrate to one file: 
BW.keystore + import amx340.pem


Key Alias: amx,   password:   tibco123
Key Alias: bw, 	 password :   tibco123


BW Service: 
BW.keystore is only used for BW side.

1. KeyStore_Server, need created from amx340.pem
2. Identify_Server, need to provider bw_id.jks (now its BW.keystore)

AMX side:
SSL HttpClient:

SSLClient requies 
Keystore provider as Trust Store: this will use amx_trust.jks (now RSA1024.keystore will have trust cert)
Enable Mutual Auth,
Keystore provider having identity is: amx_id.jks (now RSA1024.keystore will have amx_id)
(alias is amx/tibco123) 


Hints for Steps:

In the BW project,
1. First make sure one-way Auth is working fine (by selftest client processes)
Here we can see the BW service is running on port 6767 with ssl.

C:\Users\p-mguo>netstat -aon | find "6767"
  TCP    0.0.0.0:6767           0.0.0.0:0              LISTENING       11136
  TCP    [::]:6767              [::]:0                 LISTENING       11136
If the configration of BW is incorrect, the port will not be taken.

2. Make sure the local BW project (Mutual Auth) is working file, use SOAP UI to call the BAT 5.7 service. (here you can manaully change the httpsClient, sslClient,sslServer to use the new keystore files)
The SOAP UI Request is bit different as generated WSDL (it will get NPE if you use WSDL generate by Admin), you need to copy from Lisa case , that is as following:

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:hel="http://www.example.com/HelloWorld1/sayHelloWorld1Impl/HelloWorld1PT1" xmlns:hel1="http://ns.tibco.com/Hello1/">
   <soapenv:Header/>
   <soapenv:Body>
     <sayHelloWorld>
            <name>
                <ns0:HelloWorldRequest xmlns:ns0 = "http://ns.tibco.com/Hello1/">{{requestString}} abt</ns0:HelloWorldRequest>
            </name>
        </sayHelloWorld>
   </soapenv:Body>
</soapenv:Envelope>

This will get the response:

<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">
   <SOAP-ENV:Header/>
   <SOAP-ENV:Body>
      <sayHelloWorldResponse>
         <greeting>
            <ns:HelloWorldResponse xmlns:ns="http://ns.tibco.com/Hello1/" xmlns:ns0="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">Hello {{requestString}} abt</ns:HelloWorldResponse>
         </greeting>
      </sayHelloWorldResponse>
   </SOAP-ENV:Body>
</SOAP-ENV:Envelope>

From above we can see the local BW project is working fine by BAT5.7 service invocation. 

3. Deploy the EAR file to Administrator.
3.1) one issue is that: make sure the Service Keystore is include to the EAR's resource and use the extenal path of the AMX.pem.
3.2) Make sure you deploy the host as "batman.na.tibco.com" , instead of "batman", as lisa is taking the "batman.na.tibco.com" from config file.
4. Again invoke the service with SOAP UI after re-install the httpsClient RI. 

From above we can see the BW EAR is working fine by BAT5.7 service invocation. 
Now try to make the BAT5.7 working.
5. Change the amxdata_2node_orcl.template.xml to take the new password and alias (tibco123, amx/tibco123)
6. Run the Lisa case (setup will take the new RT configruation and and 5.7.tst is not changed, just updated with new BW project and ear file)





