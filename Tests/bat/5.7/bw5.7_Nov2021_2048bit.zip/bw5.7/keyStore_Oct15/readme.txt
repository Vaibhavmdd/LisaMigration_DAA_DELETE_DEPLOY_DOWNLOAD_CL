keystore password: tibco123

amx340_id
Exported to amx340.pem (will be imported to BW trustKeystore)
amx340_trust  ( import BW_CER)

bw57_id
Exported to bw_CER (will be imported to amx trustkeystore)
bw57_trust
(import amx_CER)

Key Alias: amx ,  password: tibco123
Key Alias: bw, 	  password : tibco123

Update it with 2048 bit public key.