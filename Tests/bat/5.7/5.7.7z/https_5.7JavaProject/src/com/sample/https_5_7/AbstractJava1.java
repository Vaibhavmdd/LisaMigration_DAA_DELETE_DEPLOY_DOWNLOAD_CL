/**
 *
 */
package com.sample.https_5_7;

import org.osoa.sca.annotations.Reference;

import com.example.www.HelloWorld1.sayHelloWorld1Impl.HelloWorld1PT;

import com.tibco.ns.hello1.HelloWorldResponseDocument;
import com.tibco.ns.hello1.HelloWorldRequestDocument;

/**
 * Abstract interface generated for component "Java1".
 *
 * This class will be completely generated, add custom code to the subclass: 
 * {@link com.sample.https_5_7.Java1 com.sample.https_5_7.Java1}
 *
 * @Generated TEMPL003
 */
public abstract class AbstractJava1 implements HelloWorld1PT {

	/**
	 * Implementation of the WSDL operation: sayHelloWorld	 */
	public abstract HelloWorldResponseDocument sayHelloWorld(
			HelloWorldRequestDocument name);

	private HelloWorld1PT Reference1;

	@Reference(name = "Reference1")
	public void setReference1(HelloWorld1PT Reference1) {
		this.Reference1 = Reference1;
	}

	public HelloWorld1PT getReference1() {
		return this.Reference1;
	}

}
