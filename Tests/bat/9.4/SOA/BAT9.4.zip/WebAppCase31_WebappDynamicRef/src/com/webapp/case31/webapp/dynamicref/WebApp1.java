package com.webapp.case31.webapp.dynamicref;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.osoa.sca.annotations.Context;
import org.osoa.sca.annotations.Reference;
import org.w3c.dom.Element;

import com.example.xmlns._1235597799193.addressoperationimpl.server.addressoperationimpl.server.AddressPort;
import com.example.xmlns._1235597799193.addressoperationimpl.server.addressoperationimpl.server.Address_FaultException;
import com.tibco.amf.platform.runtime.extension.context.ComponentContext;
import com.tibco.amf.platform.runtime.extension.context.EndpointReference;
import com.tibco.amf.platform.runtime.extension.context.MutableRequestContext;
import com.tibco.amf.platform.runtime.extension.support.ElementEndpointReference;
import com.tibco.amf.platform.runtime.extension.support.ServiceVirtualizationHelper;
import com.tibco.matrix.qa.xsd.address.AddressElementDocument;
import com.tibco.matrix.qa.xsd.address.AddressElementDocument.AddressElement;


/**
 * Implementation of WebApp1 component.
 *
 */
public class WebApp1 extends AbstractWebApp1 implements Servlet {

	String envName = "";
	String appName = "";
	String serviceName = "";
	String target= "soap";
	URI targetURI = null;	
	
	
	@Context
	ComponentContext context;	
	
	/**
	 * @see WebApp1#WebApp1()
	 */
	
	public WebApp1() {
		super();
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see Servlet#getServletConfig()
	 */
	public ServletConfig getServletConfig() {
		return null;
	}

	/**
	 * @see Servlet#getServletInfo()
	 */
	public String getServletInfo() {
		return null;
	}

	private void setEPR() throws URISyntaxException {
		
		EndpointReference<Element> epr = null;
	
		targetURI =ServiceVirtualizationHelper.createPromotedServiceURI(envName, appName, serviceName);
		
		
		epr = new ElementEndpointReference(targetURI);
		
		MutableRequestContext mctxt;
		mctxt = (MutableRequestContext) context.createMutableRequestContext();
		mctxt.setEndpointReference(epr);
		context.setRequestContext(mctxt);
	
	}
	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {

		String name =request.getParameter("name");
		if(name == null) {
			this.appName = "Case31_Provider";
		}else
			this.appName=name;
		
		String address =request.getParameter("address");
		if(address == null) {
			this.serviceName = "SDRAppNamePSCase31_p1";				
		}else
			this.serviceName=address;

		
		String city =request.getParameter("city");
		if(city == null) {
			this.target = "soap";
		}else
			this.target = city;
		
		AddressElementDocument addressRequestDoc= AddressElementDocument.Factory.newInstance();
		AddressElement addressElement =AddressElement.Factory.newInstance();
		addressElement.setAddress(address);
		addressElement.setName(name);
		addressElement.setCity(city);
		addressElement.setState("My State");
		addressElement.setZip(22222);
		
		addressRequestDoc.setAddressElement(addressElement);
		
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<head>");
		writer.println("<title>Webapp Test application.</title>");
		writer.println("</head>");
		writer.println("<body bgcolor=white>");
		writer.println("<table border=\"0\">");
		writer.println("<tr>");
		writer.println("<td>");
		writer.println("<br> address information  " + address + " !" + " This is the WTP WebApp Component</br>");
		writer.println("<br>set EPR ...</br>");
		
		try {		
			
			this.envName= this.context.getEnvironmentName();
			setEPR();
			writer.println("<br>targetURI=" + this.targetURI.toASCIIString()+ " </br>");
			writer.println("<br>before invoking reference..envName=" + this.context.getEnvironmentName() + "</br>");
			writer.println("<br>beforeinvoking reference.. appName=" + this.appName + "</br>");
			writer.println("<br>invoking reference..serviceName=" + this.serviceName+ "</br>");
			
			writer.println("<br>before invoking reference..TargeURI=" + this.targetURI.toString() + "</br>");
			writer.println("<br>invoking reference... </br>");
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			AddressElementDocument returnDoc = this.getAddressPort().addressOperation(addressRequestDoc);
	
			writer.println("<br>reference operation result Name: " + returnDoc.getAddressElement().getName() + "</br>");
			writer.println("<br>reference operation result Address: " + returnDoc.getAddressElement().getAddress() + "</br>");
			writer.println("<br>reference operation result City: " + returnDoc.getAddressElement().getCity() + "</br>");
			writer.println("<br>reference operation result State: " + returnDoc.getAddressElement().getState() + "</br>");
			writer.println("<br>reference operation result Zip: " + String.valueOf(returnDoc.getAddressElement().getZip()) + "</br>");

			
		} catch (Address_FaultException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

		writer.println("<br>invoking reference is done... </br>");
		writer.println("</td>");
		writer.println("</tr>");
		writer.println("</table>");
		writer.println("</body>");
		writer.println("</html>");
		writer.flush();
		writer.close(); 
	}
	private AddressPort AddressPort;

	@Reference(name = "AddressPort")
	public void setAddressPort(AddressPort AddressPort) {
		this.AddressPort = AddressPort;
	}

	public AddressPort getAddressPort() {
		return this.AddressPort;
	}



}
