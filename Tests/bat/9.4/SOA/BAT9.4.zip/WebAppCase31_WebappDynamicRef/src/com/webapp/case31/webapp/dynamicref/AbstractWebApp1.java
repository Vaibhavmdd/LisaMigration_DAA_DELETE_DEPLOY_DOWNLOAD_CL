package com.webapp.case31.webapp.dynamicref;

import javax.servlet.http.HttpServlet;

import org.osoa.sca.annotations.Context;
import org.osoa.sca.annotations.Property;
import org.osoa.sca.annotations.Reference;
import com.example.xmlns._1235597799193.addressoperationimpl.server.addressoperationimpl.server.AddressPort;
import com.tibco.amf.platform.runtime.extension.context.ComponentContext;
import com.tibco.matrix.qa.xsd.address.AddressElementDocument;

/**
 * Abstract interface generated for component "WebApp1".
 *
 * This class will be completely generated, add custom code to the subclass: 
 * {@link com.webapp.case31.webapp.dynamicref.AbstractWebApp1 AbstractWebApp1}
 *
 * @Generated TEMPL003
 */
public abstract class AbstractWebApp1 extends HttpServlet {

	
}
