<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:add="http://tibco.com/matrix/qa/xsd/address">
   <soapenv:Header/>
   <soapenv:Body>
      <add:Address_Element>
         <add:Name>Case31_Provider</add:Name>
         <add:Address>SDRAppNamePSCase31_p3</add:Address>
         <add:City>soap2</add:City>
         <add:State>a</add:State>
         <add:Zip>1</add:Zip>
      </add:Address_Element>
   </soapenv:Body>
</soapenv:Envelope>


input url = http://localhost:8011/case31/WebApp1?name=Case31_Provider&address=SDRAppNamePSCase31_p1&city=abc



address information SDRAppNamePSCase31_p1 ! This is the WTP WebApp Component

set EPR ...

targetURI=urn:amx:DevEnvironment/Case31_Provider#service(SDRAppNamePSCase31_p1) 

before invoking reference..envName=DevEnvironment

beforeinvoking reference.. appName=Case31_Provider

invoking reference..serviceName=SDRAppNamePSCase31_p1

before invoking reference..TargeURI=urn:amx:DevEnvironment/Case31_Provider#service(SDRAppNamePSCase31_p1)

invoking reference... 

reference operation result Name: Case31_Provider

reference operation result Address: SDRAppNamePSCase31_p1

reference operation result City: abc

reference operation result State: My State

reference operation result Zip: 10001

invoking reference is done... 
