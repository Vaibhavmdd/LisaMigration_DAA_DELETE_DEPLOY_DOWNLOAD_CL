package com.sample.case31.dynamiceprjava;

import org.osoa.sca.annotations.Reference;
import com.example.xmlns._1235597799193.addressoperationimpl.server.addressoperationimpl.server.AddressPort;
import com.tibco.matrix.qa.xsd.address.AddressElementDocument;

/**
 * Abstract interface generated for component "Java1".
 *
 * This class will be completely generated, add custom code to the subclass: 
 * {@link com.sample.case31.dynamiceprjava.AbstractJava1 AbstractJava1}
 *
 * @Generated TEMPL003
 */
public abstract class AbstractJava1 implements AddressPort {

	/**
	 * Implementation of the WSDL operation: AddressOperation	 */
	public abstract AddressElementDocument addressOperation(AddressElementDocument inPart)
			throws com.example.xmlns._1235597799193.addressoperationimpl.server.addressoperationimpl.server.Address_FaultException;

	private AddressPort AddressPort;

	@Reference(name = "AddressPort")
	public void setAddressPort(AddressPort AddressPort) {
		this.AddressPort = AddressPort;
	}

	public AddressPort getAddressPort() {
		return this.AddressPort;
	}

}
