package com.sample.case31.dynamiceprjava;

import org.osoa.sca.annotations.Init;
import org.w3c.dom.Element;

import java.net.URI;
import java.net.URISyntaxException;

import org.osoa.sca.annotations.Context;
import org.osoa.sca.annotations.Destroy;
import com.example.xmlns._1235597799193.addressoperationimpl.server.addressoperationimpl.server.AddressPort;
import com.tibco.amf.platform.runtime.extension.context.ComponentContext;
import com.tibco.amf.platform.runtime.extension.context.EndpointReference;
import com.tibco.amf.platform.runtime.extension.context.MutableRequestContext;
import com.tibco.amf.platform.runtime.extension.support.ElementEndpointReference;
import com.tibco.amf.platform.runtime.extension.support.ServiceVirtualizationHelper;
import com.tibco.matrix.qa.xsd.address.AddressElementDocument;

/**
 * Implementation of Java1 component.
 *
 */
public class Java1 extends AbstractJava1 {
	@Context
	ComponentContext context;
	String sTarget = "soap";
	URI targetURI = null;	
	
	String envName=null;
	String appName =null;
	String serviceName= null;
	/**
	 * Initialization of Java1 component.
	 */
	@Init
	public void init() {
		// Component initialization code.
		// All properties are initialized and references are injected.
		// The Reference cannot be invoked unless "Start Service First" policy has been applied on it.
	}

	/**
	 * Disposal of Java1 component.
	 */
	@Destroy
	public void destroy() {
		// Component disposal code.
		// All properties are disposed.
	}

private void setEPR() throws URISyntaxException {
		
		EndpointReference<Element> epr = null;
	
		if(this.sTarget.equalsIgnoreCase("soap"))
			
			targetURI = new URI("http://localhost:8999/Server/AddressServer"); 
		else 
			targetURI =ServiceVirtualizationHelper.createPromotedServiceURI(envName, appName, serviceName);
				
		epr = new ElementEndpointReference(targetURI);
		
		MutableRequestContext mctxt;
		mctxt = (MutableRequestContext) context.createMutableRequestContext();
		mctxt.setEndpointReference(epr);
		context.setRequestContext(mctxt);
	
	}
	/**
	 * Implementation of the WSDL operation: AddressOperation	 */
	public AddressElementDocument addressOperation(AddressElementDocument inPart)
			throws com.example.xmlns._1235597799193.addressoperationimpl.server.addressoperationimpl.server.Address_FaultException {
		// Add the business logic here
		this.appName=inPart.getAddressElement().getName();		
		this.serviceName=inPart.getAddressElement().getAddress();
		this.envName= this.context.getEnvironmentName();
		this.sTarget = inPart.getAddressElement().getCity();
		
		try {
			this.setEPR();
			System.out.println("Trying to call targetURI=" + this.targetURI.toString());
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		AddressElementDocument addressReturnDoc= this.getAddressPort().addressOperation(inPart);
		System.out.println("repied from reference:" + addressReturnDoc.getAddressElement().getAddress());
		System.out.println("repied from reference:" + addressReturnDoc.getAddressElement().getName());
		System.out.println("repied from reference:" + addressReturnDoc.getAddressElement().getCity());
		System.out.println("repied from reference:" + addressReturnDoc.getAddressElement().getState());
		System.out.println("repied from reference:" + String.valueOf(addressReturnDoc.getAddressElement().getZip()));
		return addressReturnDoc;
	}
}
