package com.sample.bat87;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.osoa.sca.annotations.Init;
import org.osoa.sca.annotations.Destroy;

import bat87.sample.NewOperationResponseDocument.NewOperationResponse;
import bat87.sample.Sample;
import bat87.sample.NewOperationDocument;
import bat87.sample.NewOperationResponseDocument;

/**
 * Implementation of Java1 component.
 *
 */
public class Java1 extends AbstractJava1 {

	/**
	 * Initialization of Java1 component.
	 */
	@Init
	public void init() {
		// Component initialization code.
		// All properties are initialized and references are injected.
		
	}

	/**
	 * Disposal of Java1 component.
	 */
	@Destroy
	public void destroy() {
		// Component disposal code.
		// All properties are disposed.
	}

	/**
	 * Implementation of the WSDL operation: NewOperation	 */
	public NewOperationResponseDocument newOperation(
			NewOperationDocument parameters) {
		// Add the business logic here
	    NewOperationResponseDocument newDoc = NewOperationResponseDocument.Factory.newInstance();
	    NewOperationResponse newResp = NewOperationResponse.Factory.newInstance();
	    String sOutStr = null;
	    
		 DataSource ds = getProperty1();
		   
		 try {
		      Connection con = ds.getConnection();
		      String sDBName =  con.getMetaData().getDatabaseProductName();
		      String sDBVrsion =  con.getMetaData().getDatabaseProductVersion();
		      int iDBMajorVersion = con.getMetaData().getDatabaseMajorVersion();
		      int iDMinorVersion = con.getMetaData().getDatabaseMinorVersion();		      
		    
		      String username = con.getMetaData().getUserName();
		      
		      sOutStr = "User : " + username + " is connected to DB " +sDBName +",of version : "+ sDBVrsion + "["+iDBMajorVersion + " " + iDMinorVersion   + "]" + 
		      " using driver version is: " + con.getMetaData().getDriverVersion();
		      System.out.println(sOutStr);
		      
		      con.close();
		      
		    }
		    catch (SQLException e) {
		      e.printStackTrace();
		      sOutStr = e.toString();
		    }
		    		
		    newResp.setOut(sOutStr);
		    newDoc.setNewOperationResponse(newResp);		    
		    
		return newDoc;
	}

}
