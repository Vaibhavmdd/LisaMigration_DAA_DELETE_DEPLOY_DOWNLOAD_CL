package com.sample.bat87;

import org.osoa.sca.annotations.Property;
import javax.sql.DataSource;
import bat87.sample.Sample;
import bat87.sample.NewOperationDocument;
import bat87.sample.NewOperationResponseDocument;

/**
 * Abstract interface generated for component "Java1".
 *
 * This class will be completely generated, add custom code to the subclass: 
 * {@link com.sample.bat87.AbstractJava1 AbstractJava1}
 *
 * @Generated TEMPL003
 */
public abstract class AbstractJava1 implements Sample {

	private DataSource Property1;

	@Property(name = "Property1")
	public void setProperty1(DataSource Property1) {
		this.Property1 = Property1;
	}

	public DataSource getProperty1() {
		return Property1;
	}

	/**
	 * Implementation of the WSDL operation: NewOperation	 */
	public abstract NewOperationResponseDocument newOperation(
			NewOperationDocument parameters);

}
